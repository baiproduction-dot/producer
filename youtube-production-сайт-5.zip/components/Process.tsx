import React, { useState, useEffect } from 'react';
import { Lightbulb, Camera, Rocket } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';
import { motion } from 'framer-motion';

const steps = [
  {
    icon: Lightbulb,
    title: "Креатив",
    desc: "Придумываем сценарии. Анализируем нишу. Создаем стратегию.",
    detail: "Вам не нужно ломать голову над темами."
  },
  {
    icon: Camera,
    title: "Съемка & Продакшн",
    desc: "Снимаем. Монтируем. Делаем цветокоррекцию и саунд-дизайн.",
    detail: "Получаете качественный визуал под ключ."
  },
  {
    icon: Rocket,
    title: "Продвижение",
    desc: "Публикация. Дизайн. SEO оптимизация. Работа с алгоритмами.",
    detail: "Контент реально привлекает внимание и клиентов."
  }
];

export const Process: React.FC = () => {
    const [isDesktop, setIsDesktop] = useState(false);

    useEffect(() => {
        const check = () => setIsDesktop(window.innerWidth >= 768);
        check();
        window.addEventListener('resize', check);
        return () => window.removeEventListener('resize', check);
    }, []);

  return (
    <section className="py-8 px-4 relative z-10">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-8 text-gray-900">
          Как мы работаем
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {steps.map((step, idx) => (
            <motion.div 
                key={idx}
                initial={isDesktop ? { opacity: 0, y: 20 } : {}}
                whileInView={isDesktop ? { opacity: 1, y: 0 } : {}}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
            >
              <GlassCard className="h-full p-8 flex flex-col items-center text-center hover:bg-white/40 transition-colors">
                <div className="w-20 h-20 rounded-full bg-white/60 backdrop-blur-md shadow-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <step.icon className="w-10 h-10 text-gray-800" />
                </div>
                
                <h3 className="text-2xl font-bold mb-4">{step.title}</h3>
                <p className="text-gray-600 mb-6 flex-grow">{step.desc}</p>
                
                <div className="text-sm font-medium text-red-600 bg-red-50/50 px-4 py-2 rounded-full border border-red-100">
                  {step.detail}
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};