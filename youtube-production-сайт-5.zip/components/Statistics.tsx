import React, { useState, useEffect } from 'react';
import { motion, useMotionValue, useTransform, useSpring, useScroll } from 'framer-motion';
import { Smartphone, MessageCircle, MonitorPlay, TrendingUp, BarChart3, ArrowRight } from 'lucide-react';

const metrics = [
  {
    id: 1,
    title: "Shorts / вертикальные ролики",
    value: "24–28",
    suffix: "тыс.",
    sub: "просмотров",
    icon: Smartphone,
    color: "from-blue-400 to-indigo-400",
    delay: 0.1
  },
  {
    id: 2,
    title: "Комментарии",
    value: "+20-40 ",
    suffix: "",
    sub: "делаем обсуждаемые ролики",
    icon: MessageCircle,
    color: "from-purple-400 to-pink-400",
    delay: 0.2
  },
  {
    id: 3,
    title: "YouTube выпуски 12–20 мин",
    value: "45–50",
    suffix: "тыс.",
    sub: "просмотров",
    icon: MonitorPlay,
    color: "from-emerald-400 to-teal-400",
    delay: 0.3
  }
];

export const Statistics: React.FC = () => {
  const [isDesktop, setIsDesktop] = useState(false);
  const { scrollYProgress } = useScroll();
  
  const yGlow1 = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const yGlow2 = useTransform(scrollYProgress, [0, 1], [0, -150]);

  useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return (
    <section className="relative py-12 px-4 overflow-hidden bg-[#0a0a0a] text-white">
      {/* --- Ambient Background (Liquid Glass Effect) --- */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Deep radial gradients */}
        <motion.div 
            style={{ y: isDesktop ? yGlow1 : 0 }}
            className="absolute top-[-20%] left-[20%] w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[120px] mix-blend-screen animate-pulse" 
        />
        <motion.div 
            style={{ y: isDesktop ? yGlow2 : 0 }}
            className="absolute bottom-[-10%] right-[10%] w-[500px] h-[500px] bg-purple-600/20 rounded-full blur-[100px] mix-blend-screen" 
        />
        
        {/* Grid pattern overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_80%)]" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Header */}
        <div className="text-center mb-12 max-w-3xl mx-auto">
          <motion.div
            initial={isDesktop ? { opacity: 0, y: 20 } : {}}
            whileInView={isDesktop ? { opacity: 1, y: 0 } : {}}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-blue-300 text-sm font-medium mb-6 shadow-[0_0_15px_rgba(59,130,246,0.2)]">
              <BarChart3 className="w-4 h-4" />
              <span>Результативность</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-semibold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60">
              Средняя статистика <br/> наших работ
            </h2>
            
            <p className="text-lg md:text-xl text-gray-400 font-light leading-relaxed">
              Мы показываем средние охваты роликов наших клиентов, чтобы вы сразу увидели, какие результаты дает наша работа.
            </p>
          </motion.div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {metrics.map((metric) => (
            <TiltCard key={metric.id} isDesktop={isDesktop} delay={metric.delay}>
              <div className="relative h-full p-8 rounded-[2rem] bg-white/5 backdrop-blur-xl border border-white/10 overflow-hidden group">
                {/* Internal Glow on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${metric.color} opacity-0 group-hover:opacity-10 transition-opacity duration-700 blur-[80px] pointer-events-none`} />
                
                <div className="relative z-10 flex flex-col h-full justify-between">
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center mb-6 shadow-inner border border-white/5">
                    <metric.icon className="w-6 h-6 text-white/90" />
                  </div>

                  {/* Text */}
                  <div>
                    <h3 className="text-lg font-medium text-gray-300 mb-4 h-12 flex items-center">
                      {metric.title}
                    </h3>
                    
                    {/* Big Animated Number */}
                    <div className="flex items-baseline gap-1 mb-2">
                       <motion.span 
                          initial={isDesktop ? { opacity: 0, y: 40, filter: "blur(10px)" } : {}}
                          whileInView={isDesktop ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
                          viewport={{ once: true }}
                          transition={{ duration: 0.8, delay: metric.delay, type: "spring", stiffness: 100 }}
                          className="text-5xl md:text-6xl font-bold text-white tracking-tighter drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]"
                       >
                         {metric.value}
                       </motion.span>
                       <span className="text-xl text-gray-400 font-medium">{metric.suffix}</span>
                    </div>
                    
                    <p className="text-sm text-gray-500 font-medium uppercase tracking-wider">
                      {metric.sub}
                    </p>
                  </div>

                  {/* Graphic Visual (Abstract Bar) */}
                  <div className="mt-8 h-1 w-full bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      initial={isDesktop ? { width: 0 } : { width: '100%' }}
                      whileInView={isDesktop ? { width: '100%' } : {}}
                      viewport={{ once: true }}
                      transition={{ duration: 1.5, delay: metric.delay + 0.2, ease: "easeOut" }}
                      className={`h-full bg-gradient-to-r ${metric.color} shadow-[0_0_10px_rgba(255,255,255,0.5)]`}
                    />
                  </div>
                </div>
              </div>
            </TiltCard>
          ))}
        </div>

        {/* Footer Text & CTA */}
        <motion.div 
          initial={isDesktop ? { opacity: 0 } : {}}
          whileInView={isDesktop ? { opacity: 1 } : {}}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-12 text-center max-w-2xl mx-auto"
        >
          <div className="p-px bg-gradient-to-r from-transparent via-white/20 to-transparent rounded-full mb-8" />
          
          <p className="text-lg md:text-xl font-medium text-transparent bg-clip-text bg-gradient-to-r from-blue-200 via-white to-purple-200 leading-snug mb-8">
            Мы создаем контент, который растет со временем, удерживает аудиторию и усиливает ваш бренд.
          </p>

          <a 
            href="#formats"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-gray-900 rounded-full font-bold hover:bg-gray-100 transition-all shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:shadow-[0_0_30px_rgba(255,255,255,0.5)] hover:scale-105"
          >
            Хочу такие результаты
            <ArrowRight className="w-5 h-5" />
          </a>
        </motion.div>

      </div>
    </section>
  );
};

// --- Helper Component for 3D Tilt Effect ---
interface TiltCardProps {
  children: React.ReactNode;
  isDesktop: boolean;
  delay: number;
}

const TiltCard: React.FC<TiltCardProps> = ({ children, isDesktop, delay }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseX = useSpring(x, { stiffness: 150, damping: 15 });
  const mouseY = useSpring(y, { stiffness: 150, damping: 15 });

  const rotateX = useTransform(mouseY, [-0.5, 0.5], ["5deg", "-5deg"]);
  const rotateY = useTransform(mouseX, [-0.5, 0.5], ["-5deg", "5deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDesktop) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseXFromCenter = e.clientX - rect.left - width / 2;
    const mouseYFromCenter = e.clientY - rect.top - height / 2;
    x.set(mouseXFromCenter / width);
    y.set(mouseYFromCenter / height);
  };

  const handleMouseLeave = () => {
    if (!isDesktop) return;
    x.set(0);
    y.set(0);
  };

  if (!isDesktop) {
      return <div>{children}</div>;
  }

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
      }}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      className="perspective-1000 h-full"
    >
      {children}
    </motion.div>
  );
};
