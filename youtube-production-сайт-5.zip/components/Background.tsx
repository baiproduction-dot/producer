import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

export const Background: React.FC = () => {
  const [isDesktop, setIsDesktop] = useState(false);
  const { scrollY } = useScroll();

  // Parallax transforms
  const y1 = useTransform(scrollY, [0, 2000], [0, 400]); // Moves down slower
  const y2 = useTransform(scrollY, [0, 2000], [0, -300]); // Moves up
  const rotate1 = useTransform(scrollY, [0, 2000], [0, 45]);

  useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return (
    <div className="fixed inset-0 w-full h-full -z-10 overflow-hidden bg-[#f2f2f7]">
      {/* Red/Pink Accent Blob */}
      <motion.div
        style={{ y: isDesktop ? y1 : 0, rotate: isDesktop ? rotate1 : 0 }}
        animate={isDesktop ? {
          x: [0, 100, 0],
          scale: [1, 1.1, 1],
        } : {}}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-red-400/20 rounded-full blur-[100px]"
      />

      {/* Blue/Gray Cool Blob */}
      <motion.div
        style={{ y: isDesktop ? y2 : 0 }}
        animate={isDesktop ? {
          x: [0, -100, 0],
          scale: [1, 1.2, 1],
        } : {}}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute bottom-[-10%] right-[-10%] w-[60vw] h-[60vw] bg-slate-300/30 rounded-full blur-[120px]"
      />

      {/* Center White Glow - Static reference point */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vw] bg-white/40 rounded-full blur-[80px]" />
    </div>
  );
};