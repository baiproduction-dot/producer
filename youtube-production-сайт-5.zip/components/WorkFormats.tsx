import React from 'react';
import { MessageCircle, Video, ArrowRight, Globe, Users, Check, Sparkles } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';

export const WorkFormats: React.FC = () => {
  return (
    <section className="py-20 px-4 relative z-10" id="formats">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-xs font-bold uppercase tracking-wider mb-4 border border-blue-100">
             <Sparkles className="w-3 h-3" />
             Форматы работы
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tight">
            Как мы можем поработать
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-10 max-w-5xl mx-auto">
          {/* Consultation */}
          <GlassCard className="p-8 md:p-10 flex flex-col h-full hover:bg-white/60 transition-colors border border-white/50">
            <div className="flex-grow">
              <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-8 text-gray-700">
                <MessageCircle className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Консультация
              </h3>
              <p className="text-gray-600 leading-relaxed text-lg">
                Провожу консультации. Разбираем ваши текущие задачи, вопросы по стратегии, контенту и продвижению.
              </p>
              
              <ul className="mt-8 space-y-3">
                 <li className="flex items-start gap-3 text-gray-600">
                    <Check className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    <span>Аудит текущего канала</span>
                 </li>
                 <li className="flex items-start gap-3 text-gray-600">
                    <Check className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    <span>Стратегия роста</span>
                 </li>
                 <li className="flex items-start gap-3 text-gray-600">
                    <Check className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    <span>Ответы на вопросы</span>
                 </li>
              </ul>
            </div>
            
            <div className="mt-10">
              <a 
                href={`https://t.me/bai_khairullin?text=${encodeURIComponent("Привет! Меня интересует консультация. У меня есть вопрос:")}`}
                target="_blank" 
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white border border-gray-200 text-gray-900 rounded-xl font-bold hover:bg-gray-50 hover:border-gray-300 transition-all w-full shadow-sm hover:shadow-md"
              >
                Записаться
              </a>
            </div>
          </GlassCard>

          {/* Content Creation Support */}
          <GlassCard className="p-8 md:p-10 flex flex-col h-full relative overflow-hidden ring-1 ring-blue-500/20" highlight={true}>
            {/* Subtle background gradient */}
            <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 to-transparent pointer-events-none" />
            
            <div className="relative z-10 flex-grow">
              <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center mb-8 text-white shadow-lg shadow-blue-500/30">
                <Video className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Сопровождение по созданию контента
              </h3>
              
              <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
                <p>
                  Помогаю предпринимателям создавать контент. Работаю по всей России — <span className="font-semibold text-gray-900">онлайн</span> и <span className="font-semibold text-gray-900">офлайн</span>.
                </p>
                <p className="p-4 bg-white/60 rounded-xl border border-blue-100 text-base">
                   <span className="block font-bold text-gray-900 mb-1">Не хотите снимать сами?</span>
                   Я помогу вам создать контент <span className="font-semibold text-blue-700">с моей командой</span>.
                </p>
              </div>
              
              <div className="flex flex-wrap gap-3 mt-8">
                 <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg text-sm font-medium text-gray-700 border border-gray-200 shadow-sm">
                    <Globe className="w-4 h-4 text-blue-500" />
                    РФ и Мир
                 </div>
                 <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg text-sm font-medium text-gray-700 border border-gray-200 shadow-sm">
                    <Users className="w-4 h-4 text-blue-500" />
                    Команда
                 </div>
              </div>
            </div>

            <div className="relative z-10 mt-10">
              <a 
                href={`https://t.me/bai_khairullin?text=${encodeURIComponent("Привет! Хочу обсудить сопровождение по созданию контента.")}`}
                target="_blank" 
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gray-900 text-white rounded-xl font-bold hover:bg-black transition-all w-full shadow-xl hover:shadow-2xl hover:-translate-y-1"
              >
                Обсудить сопровождение
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </GlassCard>
        </div>
      </div>
    </section>
  );
};
