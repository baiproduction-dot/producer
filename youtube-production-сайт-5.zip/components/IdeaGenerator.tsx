import React, { useState, useEffect } from 'react';
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Sparkles, Send, X, Loader2, Play, Hash, AlertTriangle, Lightbulb, Video, Zap } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';

interface Idea {
  title: string;
  hook: string;
  concept: string;
  tags: string[];
}

const ideaSchema: Schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING },
      hook: { type: Type.STRING },
      concept: { type: Type.STRING },
      tags: { type: Type.ARRAY, items: { type: Type.STRING } }
    }
  }
};

const MAX_DAILY_LIMIT = 5;

const LOADING_PHRASES = [
  "Анализирую нишу...",
  "Ищу тренды YouTube...",
  "Генерирую хуки...",
  "Подбираю теги...",
  "Финальная магия..."
];

export const IdeaGenerator: React.FC = () => {
  const [niche, setNiche] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingText] = useState(LOADING_PHRASES[0]);
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [error, setError] = useState('');
  const [selectedIdea, setSelectedIdea] = useState<Idea | null>(null);
  const [remainingGenerations, setRemainingGenerations] = useState(MAX_DAILY_LIMIT);

  useEffect(() => {
    checkLimit();
  }, []);

  // Cycle through loading phrases
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (loading) {
      let i = 0;
      setLoadingText(LOADING_PHRASES[0]);
      interval = setInterval(() => {
        i = (i + 1) % LOADING_PHRASES.length;
        setLoadingText(LOADING_PHRASES[i]);
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const checkLimit = () => {
    const storageKey = 'bai_production_limit';
    const today = new Date().toDateString();
    
    try {
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        const data = JSON.parse(stored);
        if (data.date === today) {
          setRemainingGenerations(MAX_DAILY_LIMIT - data.count);
          return data.count < MAX_DAILY_LIMIT;
        }
      }
      // Reset if new day or no data
      localStorage.setItem(storageKey, JSON.stringify({ date: today, count: 0 }));
      setRemainingGenerations(MAX_DAILY_LIMIT);
      return true;
    } catch (e) {
      return true;
    }
  };

  const incrementUsage = () => {
    const storageKey = 'bai_production_limit';
    const today = new Date().toDateString();
    
    try {
      const stored = localStorage.getItem(storageKey);
      let count = 0;
      if (stored) {
        const data = JSON.parse(stored);
        if (data.date === today) {
          count = data.count;
        }
      }
      const newCount = count + 1;
      localStorage.setItem(storageKey, JSON.stringify({ date: today, count: newCount }));
      setRemainingGenerations(MAX_DAILY_LIMIT - newCount);
    } catch (e) {
      console.error("Storage error", e);
    }
  };

  const generateIdeas = async () => {
    if (!niche.trim()) return;
    
    if (!checkLimit()) {
      setError(`Вы исчерпали лимит генераций на сегодня (${MAX_DAILY_LIMIT} раз). Возвращайтесь завтра!`);
      return;
    }

    const apiKey = process.env.API_KEY;
    
    if (!apiKey) {
      setError('Ошибка конфигурации API Key.');
      return;
    }

    setLoading(true);
    setError('');
    setIdeas([]);

    try {
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Ниша: ${niche}`,
        config: {
          systemInstruction: `Ты — креативный YouTube-продюсер. Пользователь дал нишу: "${niche}". Сгенерируй 3 идей для ютуб ролика Для каждой: заголовок (1–4 слова), hook (что сказать в первые 3 сек), концепция (1–2 предложения), 3 хештега, В конце добавь строку: «Нравится идея? Сделайте за меня».`,
          responseMimeType: "application/json",
          responseSchema: ideaSchema,
          temperature: 0.8
        }
      });

      if (response.text) {
        const data = JSON.parse(response.text);
        setIdeas(data);
        incrementUsage(); 
      }
    } catch (err) {
      console.error(err);
      setError('Не получилось сгенерировать идеи — попробуйте переформулировать нишу.');
    } finally {
      setLoading(false);
    }
  };

  const openModal = (idea: Idea) => setSelectedIdea(idea);
  const closeModal = () => setSelectedIdea(null);

  return (
    <section className="py-8 px-4 relative z-20 overflow-hidden" id="generator">
      {/* Decorative Blobs for this section */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-4xl opacity-30 pointer-events-none">
        <div className="absolute top-0 left-0 w-64 h-64 bg-blue-300/30 rounded-full blur-[80px]" />
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-red-300/30 rounded-full blur-[80px]" />
      </div>

      {/* --- Floating Icons (Static) --- */}
      <div className="absolute top-[10%] left-[5%] md:left-[10%] hidden md:block opacity-70 pointer-events-none">
        <GlassCard className="w-16 h-16 flex items-center justify-center !rounded-2xl bg-yellow-50/40 backdrop-blur-sm border-yellow-200/50">
          <Lightbulb className="w-8 h-8 text-yellow-500 fill-yellow-500/20" />
        </GlassCard>
      </div>

      <div className="absolute bottom-[20%] right-[5%] md:right-[10%] hidden md:block opacity-70 pointer-events-none">
        <GlassCard className="w-20 h-20 flex items-center justify-center !rounded-2xl bg-red-50/40 backdrop-blur-sm border-red-200/50">
          <Video className="w-10 h-10 text-red-500" />
        </GlassCard>
      </div>

      <div className="absolute top-[25%] right-[15%] hidden lg:block opacity-60 pointer-events-none">
        <GlassCard className="w-12 h-12 flex items-center justify-center !rounded-xl bg-blue-50/40 backdrop-blur-sm border-blue-200/50">
          <Zap className="w-6 h-6 text-blue-500 fill-blue-500/20" />
        </GlassCard>
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-50 text-red-600 text-xs font-bold uppercase tracking-wider mb-4 border border-red-100">
            <Sparkles className="w-3 h-3" />
            AI Помощник
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">
            Генератор идей
          </h2>
          <p className="text-xl text-gray-500 font-light max-w-2xl mx-auto mb-6">
            Введите вашу нишу, и искусственный интеллект придумает 3 хайповые концепции для ваших видео.
          </p>
           
          {/* New styled disclaimer */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center gap-3 bg-white/70 backdrop-blur-lg border border-red-100 px-5 py-3 rounded-2xl shadow-sm max-w-lg">
                <div className="p-2 bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-lg shadow-red-500/20 shrink-0">
                    <Sparkles className="w-4 h-4 text-white" />
                </div>
                <p className="text-sm text-gray-700 font-medium leading-relaxed text-left">
                   Я сделал собственный генератор идей для контента. <span className="text-gray-900 font-bold">Доступ открыт всем</span> и совершенно бесплатно.
                </p>
             </div>
          </div>
          
          <div className="inline-block px-4 py-2 bg-white/50 backdrop-blur-md rounded-xl border border-gray-200 text-sm font-medium text-gray-600">
            Доступно генераций сегодня: <span className={`font-bold ${remainingGenerations === 0 ? 'text-red-500' : 'text-green-600'}`}>{remainingGenerations} из {MAX_DAILY_LIMIT}</span>
          </div>
        </div>

        {/* Input Section */}
        <div className="max-w-2xl mx-auto mb-10">
          <GlassCard className="p-2 pl-6 flex items-center gap-2 !rounded-full bg-white/70 shadow-xl shadow-blue-900/5 ring-1 ring-white/50 focus-within:ring-red-500/50 transition-all">
            <input 
              type="text" 
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && generateIdeas()}
              placeholder="Напишите вашу нишу:" 
              className="flex-grow bg-transparent border-none outline-none text-gray-800 placeholder-gray-400 text-lg font-medium py-3"
            />
            <button 
              onClick={generateIdeas}
              disabled={loading || !niche.trim() || remainingGenerations <= 0}
              className={`px-8 py-3.5 bg-gray-900 hover:bg-red-600 text-white rounded-full font-bold transition-all disabled:opacity-90 disabled:cursor-not-allowed flex items-center gap-3 shadow-lg hover:shadow-red-500/30 active:scale-95 disabled:hover:bg-gray-900 min-w-[200px] justify-center relative overflow-hidden`}
            >
              {loading ? (
                <>
                  {/* Subtle shimmer effect behind text */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] animate-[shimmer_1.5s_infinite]" />
                  <Loader2 className="w-5 h-5 animate-spin relative z-10" />
                  <span className="relative z-10 animate-pulse min-w-[140px] text-left">
                    {loadingText}
                  </span>
                </>
              ) : remainingGenerations <= 0 ? (
                <>
                  <X className="w-5 h-5" />
                  Лимит
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Придумать
                </>
              )}
            </button>
          </GlassCard>
          {error && (
            <div className="flex items-center justify-center gap-2 mt-4 text-red-500 font-medium bg-red-50 py-2 rounded-lg border border-red-100">
              <AlertTriangle className="w-4 h-4" />
              {error}
            </div>
          )}
        </div>

        {/* Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {ideas.map((idea, idx) => (
              <div
                key={idx}
                className="h-full"
              >
                <GlassCard className="h-full p-6 md:p-8 flex flex-col hover:-translate-y-2 hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.1)] transition-all duration-300 group border border-white/60">
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-red-50 text-red-600 p-2 rounded-xl">
                      <Play className="w-5 h-5 fill-red-600" />
                    </div>
                  </div>
                  
                  <h3 className="text-2xl font-black text-gray-900 leading-tight mb-3">
                    {idea.title}
                  </h3>
                  
                  <div className="mb-4">
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-wide">Hook (3 сек)</span>
                    <p className="text-gray-800 font-medium italic border-l-2 border-red-500 pl-3 py-1 my-1 bg-red-50/30 rounded-r-lg">
                      "{idea.hook}"
                    </p>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3 flex-grow">
                    {idea.concept}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {idea.tags.map((tag, tIdx) => (
                      <span key={tIdx} className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-md flex items-center">
                        <Hash className="w-3 h-3 mr-0.5 opacity-50" />
                        {tag.replace('#', '')}
                      </span>
                    ))}
                  </div>

                  <button 
                    onClick={() => openModal(idea)}
                    className="w-full py-3 bg-white border border-red-100 text-red-600 font-bold rounded-xl shadow-sm hover:bg-red-600 hover:text-white hover:shadow-red-500/30 transition-all active:scale-95 flex items-center justify-center gap-2 group-hover:border-red-200"
                  >
                    Сделайте за меня
                    <Send className="w-4 h-4" />
                  </button>
                </GlassCard>
              </div>
            ))}
        </div>
      </div>

      {/* Modal */}
      {selectedIdea && (
        <div 
          className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm"
          onClick={closeModal}
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl p-6 md:p-8 w-full max-w-lg shadow-2xl relative overflow-hidden transform transition-all"
          >
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 to-red-600" />
            <button 
              onClick={closeModal}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <h3 className="text-2xl font-bold text-gray-900 mb-2">Отличный выбор! 🔥</h3>
            <p className="text-gray-500 mb-6">
              Мы возьмем эту идею, докрутим сценарий, снимем и смонтируем.
            </p>

            <div className="bg-gray-50 rounded-2xl p-4 mb-6 border border-gray-100">
              <div className="mb-2">
                <span className="text-xs font-bold text-gray-400 uppercase">Идея</span>
                <p className="font-bold text-gray-900">{selectedIdea.title}</p>
              </div>
              <div>
                <span className="text-xs font-bold text-gray-400 uppercase">Hook</span>
                <p className="text-sm text-gray-700 italic">"{selectedIdea.hook}"</p>
              </div>
            </div>

            <div className="space-y-3">
                <a 
                href={`https://t.me/bai_khairullin?text=${encodeURIComponent(
                  `Привет! Хочу заказать реализацию видео:\n\n🚀 Идея: ${selectedIdea.title}\n🎣 Hook: ${selectedIdea.hook}\n🏢 Ниша: ${niche}`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-4 bg-[#229ED9] text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-[#1f94cc] transition-colors shadow-lg shadow-blue-400/20 active:scale-95"
              >
                <Send className="w-5 h-5" />
                Отправить в Telegram
              </a>
              
              <p className="text-xs text-center text-gray-400 pt-2">
                Нажимая кнопку, вы перейдете в чат с продюсером. <br/> Ваши данные не сохраняются на сервере.
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
