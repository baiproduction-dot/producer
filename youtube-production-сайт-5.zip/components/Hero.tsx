import React, { useState, useEffect } from 'react';
import { Play, TrendingUp, Send, Phone, Heart, Camera, MousePointerClick, MessageCircle, Briefcase, ArrowRight } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';
import { motion } from 'framer-motion';

export const Hero: React.FC = () => {
  const [isDesktop, setIsDesktop] = useState(false);

  useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const floatAnimation = isDesktop ? {
    y: [0, -20, 0],
    rotate: [0, 5, 0]
  } : {};

  return (
    <section className="relative min-h-[auto] flex flex-col justify-center items-center px-4 pt-24 pb-4 overflow-hidden">
      
      {/* --- Floating 3D Decor Elements (Animated on Desktop) --- */}
      
      {/* 1. YouTube Logo - Top Left */}
      <motion.div 
        animate={floatAnimation}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-[15%] left-[5%] xl:left-[10%] hidden lg:block z-0"
      >
        <GlassCard className="w-20 h-14 flex items-center justify-center !rounded-2xl backdrop-blur-md bg-white/40 border-white/50 shadow-xl p-3">
           {/* Official-ish YouTube Logo SVG */}
           <svg viewBox="0 0 24 24" className="w-full h-full" fill="currentColor">
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" fill="#FF0000"/>
           </svg>
        </GlassCard>
      </motion.div>

      {/* 2. Growth Graph - Bottom Right */}
      <motion.div 
        animate={floatAnimation}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        className="absolute bottom-[20%] right-[2%] xl:right-[5%] hidden lg:block z-20"
      >
        <GlassCard className="w-auto h-auto px-4 py-2 flex items-center gap-2 !rounded-2xl backdrop-blur-md bg-white/40 border-white/50 shadow-xl">
          <TrendingUp className="w-5 h-5 text-green-500" />
          <div className="flex flex-col">
            <span className="text-[10px] text-gray-600 font-medium">Рост бренда</span>
            <span className="text-base font-bold text-gray-900">x10</span>
          </div>
        </GlassCard>
      </motion.div>

      {/* 3. New: Heart/Likes - Top Right */}
      <motion.div 
        animate={floatAnimation}
        transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
        className="absolute top-[18%] right-[8%] xl:right-[15%] hidden lg:block z-0"
      >
        <GlassCard className="w-14 h-14 flex items-center justify-center !rounded-2xl backdrop-blur-md bg-white/40 border-white/50 shadow-xl">
          <Heart className="w-6 h-6 text-red-500 fill-red-500" />
        </GlassCard>
      </motion.div>

      {/* 4. New: Camera - Bottom Left */}
      <motion.div 
        animate={floatAnimation}
        transition={{ duration: 6.5, repeat: Infinity, ease: "easeInOut", delay: 1.5 }}
        className="absolute bottom-[25%] left-[8%] xl:left-[12%] hidden lg:block z-0"
      >
        <GlassCard className="w-14 h-14 p-3 flex items-center justify-center !rounded-2xl backdrop-blur-md bg-white/40 border-white/50 shadow-xl">
          <Camera className="w-6 h-6 text-gray-700" />
        </GlassCard>
      </motion.div>

      {/* 5. New: Engagement/Click - Middle Left-ish */}
      <motion.div 
         animate={floatAnimation}
         transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 2 }}
         className="absolute top-[45%] left-[2%] xl:left-[5%] hidden xl:block z-0"
      >
         <GlassCard className="px-3 py-1.5 flex items-center gap-2 !rounded-xl backdrop-blur-md bg-white/30 border-white/40 shadow-lg">
            <MousePointerClick className="w-4 h-4 text-blue-500" />
            <span className="text-xs font-semibold text-gray-700">Engagement</span>
         </GlassCard>
      </motion.div>

      {/* Main Content */}
      <div className="z-10 w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-8 items-center relative">
        
        {/* Left Column: Text */}
        <motion.div 
          initial={isDesktop ? { opacity: 0, x: -30 } : {}}
          animate={isDesktop ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center lg:items-start text-center lg:text-left order-2 lg:order-1"
        >
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter text-gray-900 mb-4 leading-none mt-2 font-inter">
            Бай Хайруллин
          </h1>
          
          <div className="relative py-2 max-w-xl">
            <p className="text-lg md:text-xl text-gray-600 font-light leading-relaxed">
              Запускаю YouTube-проекты, которые <br className="hidden md:block"/>
              <span className="font-medium text-gray-900 bg-yellow-300 px-2 py-0.5 rounded-lg mx-1">привлекают клиентов</span>, 
              <span className="font-medium text-gray-900 bg-yellow-300 px-2 py-0.5 rounded-lg mx-1">растят бренд</span> и 
              <span className="font-medium text-gray-900 bg-yellow-300 px-2 py-0.5 rounded-lg mx-1">продают</span>.
            </p>
            
            <p className="mt-4 text-lg md:text-2xl font-medium text-gray-800 leading-snug">
              Хочешь лиды? Тебе нужен YouTube . <br/>
              Ваши ролики <span className="text-red-600 font-bold">работают годами</span> и приводят клиентов вечно.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start items-center mt-6 w-full lg:w-auto flex-wrap">
            <a 
                href="https://t.me/bai_khairullin" 
                target="_blank" 
                rel="noreferrer"
                className="group relative px-5 py-3.5 bg-[#229ED9] text-white rounded-2xl font-medium text-base overflow-hidden shadow-lg shadow-blue-400/30 hover:shadow-blue-400/50 transition-all hover:-translate-y-1 w-full sm:w-auto flex items-center justify-center gap-2"
            >
                <Send className="w-5 h-5 relative z-10" />
                <span className="relative z-10">Telegram</span>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-[#229ED9] opacity-0 group-hover:opacity-100 transition-opacity" />
            </a>

            <a 
                href="https://wa.me/79509465094" 
                target="_blank" 
                rel="noreferrer"
                className="group relative px-5 py-3.5 bg-[#25D366] text-white rounded-2xl font-medium text-base overflow-hidden shadow-lg shadow-green-400/30 hover:shadow-green-400/50 transition-all hover:-translate-y-1 w-full sm:w-auto flex items-center justify-center gap-2"
            >
                <MessageCircle className="w-5 h-5 relative z-10" />
                <span className="relative z-10">WhatsApp</span>
                <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-[#25D366] opacity-0 group-hover:opacity-100 transition-opacity" />
            </a>

            <a 
                href="https://t.me/+atBVAcGcoqYwYjYy" 
                target="_blank" 
                rel="noreferrer"
                className="group relative px-5 py-3.5 bg-gray-900 text-white rounded-2xl font-medium text-base overflow-hidden shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 w-full sm:w-auto flex items-center justify-center gap-2"
            >
                <Briefcase className="w-5 h-5 relative z-10" />
                <span className="relative z-10">Кейсы</span>
            </a>
            
            <a 
                href="tel:+79509465094" 
                className="px-5 py-3.5 bg-white/60 backdrop-blur-xl border border-white/60 text-gray-900 rounded-2xl font-medium text-base hover:bg-white/90 transition-all hover:-translate-y-1 shadow-sm w-full sm:w-auto flex items-center justify-center gap-2"
            >
                <Phone className="w-5 h-5" />
                +7(950)946-50-94
            </a>
          </div>
        </motion.div>

        {/* Right Column: Photo */}
        <motion.div 
            initial={isDesktop ? { opacity: 0, x: 30 } : {}}
            animate={isDesktop ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="order-1 lg:order-2 flex justify-center lg:justify-end relative"
        >
            <div className="relative w-[280px] h-[360px] md:w-[360px] md:h-[460px] rounded-[2rem] overflow-hidden border-8 border-white/30 shadow-2xl shadow-blue-900/10 rotate-2 hover:rotate-0 transition-transform duration-500">
                <img 
                    src="https://sun9-55.userapi.com/s/v1/ig2/sOAa3EHYqRsitxt0v5IPfh1dG-THjDRC562wWTVbCrbIl1JfH1o0HYyeC8HR7QhWf3pWkuL_5dpy8XQJVK9Sh_ir.jpg?quality=95&as=32x51,48x76,72x114,108x171,160x253,240x379,360x569,480x758,540x853,640x1011,720x1138,1080x1707,1179x1863&from=bu&cs=1179x0" 
                    alt="Бай Хайруллин" 
                    className="w-full h-full object-cover"
                    loading="eager"
                    // @ts-ignore
                    fetchPriority="high"
                />
            </div>
            
            {/* Badge floating on photo */}
            <div className="absolute -bottom-4 -left-4 md:bottom-8 md:-left-8 bg-white/80 backdrop-blur-xl p-3 md:p-4 rounded-2xl shadow-lg border border-white/60 max-w-[180px] hidden md:block group cursor-pointer hover:scale-105 transition-transform">
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">Опыт</p>
                <p className="text-sm font-semibold text-gray-900 leading-tight mb-2">Создаю контент, который продает</p>
                <a 
                  href="https://t.me/+atBVAcGcoqYwYjYy" 
                  target="_blank" 
                  rel="noreferrer"
                  className="text-xs text-blue-600 font-bold flex items-center gap-1 hover:underline"
                >
                  Смотреть кейсы <ArrowRight className="w-3 h-3" />
                </a>
            </div>
        </motion.div>

      </div>
    </section>
  );
};