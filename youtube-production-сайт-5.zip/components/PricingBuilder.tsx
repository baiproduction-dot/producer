import React, { useState, useEffect } from 'react';
import { Check, Plus, Minus, Calculator, Send, AlertCircle, ShoppingBag, Video } from 'lucide-react';

export const PricingBuilder: React.FC = () => {
  // State for toggles
  const [hasStrategy, setHasStrategy] = useState(false);
  const [hasPackaging, setHasPackaging] = useState(false);
  const [hasPosting, setHasPosting] = useState(false);
  
  // State for counters
  const [productionCount, setProductionCount] = useState(0); // Combined Filming + Editing
  const [shortsCount, setShortsCount] = useState(0);

  const [totalPrice, setTotalPrice] = useState(0);

  // Prices
  const PRICE_STRATEGY = 35000;
  const PRICE_PACKAGING = 35000;
  const PRICE_POSTING = 25000;
  
  // Combined Price: Shooting + Editing per video
  const PRICE_PRODUCTION = 49000; 
  const PRICE_SHORTS = 1900;   // per short

  // Package thresholds for comparison
  const PACKAGE_FULL_PRICE = 280000;
  const PACKAGE_NO_SHOOT_PRICE = 190000;

  useEffect(() => {
    let total = 0;
    if (hasStrategy) total += PRICE_STRATEGY;
    if (hasPackaging) total += PRICE_PACKAGING;
    if (hasPosting) total += PRICE_POSTING;
    total += productionCount * PRICE_PRODUCTION;
    total += shortsCount * PRICE_SHORTS;
    setTotalPrice(total);
  }, [hasStrategy, hasPackaging, hasPosting, productionCount, shortsCount]);

  // Comparison Logic
  const getRecommendation = () => {
    if (totalPrice > PACKAGE_FULL_PRICE) {
      return {
        show: true,
        text: "Пакет «Полный продакшн» выгоднее!",
        savings: totalPrice - PACKAGE_FULL_PRICE,
        targetId: "tariffs"
      };
    }
    if (totalPrice > PACKAGE_NO_SHOOT_PRICE && productionCount === 0) {
      return {
        show: true,
        text: "Пакет «Без съёмки» выгоднее!",
        savings: totalPrice - PACKAGE_NO_SHOOT_PRICE,
        targetId: "tariffs"
      };
    }
    return { show: false, text: "", savings: 0, targetId: "" };
  };

  const recommendation = getRecommendation();

  const Counter = ({ value, setValue, max = 30 }: { value: number, setValue: (v: number) => void, max?: number }) => (
    <div className="flex items-center gap-3 bg-white/50 rounded-xl p-1 border border-white/40 shadow-inner">
      <button 
        onClick={() => setValue(Math.max(0, value - 1))}
        className="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-gray-500 hover:text-red-500 transition-colors active:scale-90"
      >
        <Minus className="w-4 h-4" />
      </button>
      <span className="w-6 text-center font-bold text-gray-900">{value}</span>
      <button 
        onClick={() => setValue(Math.min(max, value + 1))}
        className="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-gray-500 hover:text-green-500 transition-colors active:scale-90"
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );

  const Toggle = ({ label, isSelected, toggle }: { label: string, isSelected: boolean, toggle: () => void }) => (
    <div 
      onClick={toggle}
      className={`
        flex items-center justify-between p-4 rounded-2xl border cursor-pointer transition-all duration-300
        ${isSelected 
          ? 'bg-white/80 border-blue-400 shadow-md shadow-blue-100' 
          : 'bg-white/30 border-white/50 hover:bg-white/50'
        }
      `}
    >
      <span className={`font-medium ${isSelected ? 'text-gray-900' : 'text-gray-600'}`}>{label}</span>
      <div className={`
        w-6 h-6 rounded-full border flex items-center justify-center transition-colors
        ${isSelected ? 'bg-blue-500 border-blue-500 text-white' : 'bg-transparent border-gray-300'}
      `}>
        {isSelected && <Check className="w-4 h-4" />}
      </div>
    </div>
  );

  return (
    <section className="py-8 px-4 relative z-20 overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-0 w-64 h-64 bg-blue-200/20 rounded-full blur-[80px]" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-red-200/20 rounded-full blur-[80px]" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100/50 backdrop-blur-md border border-white/40 text-gray-600 text-xs font-bold uppercase tracking-wider mb-4 shadow-sm">
            <Calculator className="w-3 h-3" />
            Конструктор
          </div>
          <h2 className="text-3xl md:text-5xl font-black text-gray-900 mb-2 tracking-tight">
            Соберите свой набор
          </h2>
          <p className="text-gray-500 text-lg">
            Если не нашли подходящий под вас пакет — соберите свой
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 items-start">
          
          {/* Builder Area */}
          <div className="w-full lg:flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Toggles */}
            <div className="space-y-3">
              <Toggle label="Стратегия + Сценарии" isSelected={hasStrategy} toggle={() => setHasStrategy(!hasStrategy)} />
              <Toggle label="Упаковка (Обложки/Стиль)" isSelected={hasPackaging} toggle={() => setHasPackaging(!hasPackaging)} />
              <Toggle label="Выкладка и SEO" isSelected={hasPosting} toggle={() => setHasPosting(!hasPosting)} />
            </div>

            {/* Counters */}
            <div className="space-y-4">
               {/* Combined Production */}
               <div className={`p-4 rounded-2xl border transition-all ${productionCount > 0 ? 'bg-white/80 border-blue-400' : 'bg-white/30 border-white/50'}`}>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <Video className="w-4 h-4 text-gray-700" />
                      <span className="font-medium text-gray-900">Съёмка + Монтаж</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500 max-w-[120px] leading-tight">Готовый ролик</span>
                    <Counter value={productionCount} setValue={setProductionCount} max={10} />
                  </div>
               </div>

               {/* Shorts */}
               <div className={`p-4 rounded-2xl border transition-all ${shortsCount > 0 ? 'bg-white/80 border-blue-400' : 'bg-white/30 border-white/50'}`}>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-gray-900">Монтаж Shorts</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">Вертикальные ролики</span>
                    <Counter value={shortsCount} setValue={setShortsCount} max={60} />
                  </div>
               </div>
            </div>
          </div>

          {/* Sticky Summary Card */}
          <div className="w-full lg:w-96 sticky top-24">
            <div className="rounded-3xl bg-white/70 backdrop-blur-xl border border-white/60 p-6 shadow-2xl shadow-gray-200/50">
              <div className="flex items-center gap-2 mb-6 text-gray-400">
                <ShoppingBag className="w-5 h-5" />
                <span className="text-xs font-bold uppercase tracking-wider">Итоговая смета</span>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-black text-gray-900 tracking-tight">
                    {totalPrice.toLocaleString()}
                  </span>
                  <span className="text-2xl text-gray-400 font-medium">₽</span>
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Примерная стоимость выбранных услуг
                </p>
              </div>

              {/* Recommendation Alert */}
              {recommendation.show && (
                <div className="overflow-hidden mb-6">
                  <div className="bg-red-50 border border-red-100 rounded-xl p-4 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-gray-900">{recommendation.text}</p>
                      <p className="text-xs text-gray-600 mt-1">
                        Экономия: <span className="font-bold text-green-600">{recommendation.savings.toLocaleString()} ₽</span>
                      </p>
                      <a 
                        href={`#${recommendation.targetId}`}
                        className="text-xs font-bold text-red-600 underline mt-2 block hover:text-red-700"
                      >
                        Перейти к тарифам
                      </a>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                <a 
                  href={`https://t.me/bai_khairullin?text=${encodeURIComponent(`Здравствуйте! Я выбрал услуги в конструкторе:\n\nStrategy: ${hasStrategy}\nPackaging: ${hasPackaging}\nPosting: ${hasPosting}\nProduction (Shoot+Edit): ${productionCount}\nShorts: ${shortsCount}\n\nTotal estimate: ${totalPrice} rub`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-4 bg-gray-900 hover:bg-black text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95"
                >
                  Обсудить этот набор
                  <Send className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};