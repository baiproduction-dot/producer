import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Background } from './components/Background';
import { Hero } from './components/Hero';
import { Comparison } from './components/Comparison';
import { Process } from './components/Process';
import { Pricing } from './components/Pricing';
import { Footer } from './components/Footer';
import { IdeaGenerator } from './components/IdeaGenerator';

const App: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

  return (
    <main className="relative min-h-screen text-gray-900 selection:bg-red-500/30 selection:text-red-900">
      <Background />
      
      {/* Navbar Overlay */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-6 flex justify-between items-center max-w-7xl mx-auto">
        <div className="text-xl font-bold tracking-tighter mix-blend-multiply text-gray-900 relative z-50">
          БАЙ <span className="text-red-600">ПРОДАКШН</span>
        </div>
        
        {/* Desktop Nav */}
        <div className="hidden md:flex gap-8 text-sm font-medium text-gray-600 mix-blend-multiply backdrop-blur-md px-6 py-2 rounded-full border border-white/20 bg-white/20">
          <a href="#" className="hover:text-black transition-colors">Главная</a>
          <a href="#generator" className="hover:text-black transition-colors">AI Идеи</a>
          <a href="#tariffs" className="hover:text-black transition-colors">Тарифы</a>
          <a href="#contact" className="hover:text-black transition-colors">Контакты</a>
        </div>
        
        {/* Desktop CTA */}
        <a href="https://t.me/bai_khairullin" target="_blank" rel="noreferrer" className="hidden md:block px-5 py-2.5 bg-gray-900 text-white text-sm font-medium rounded-full shadow-lg hover:scale-105 transition-transform hover:bg-gray-800">
          Связаться
        </a>

        {/* Mobile Toggle */}
        <button 
          onClick={toggleMenu} 
          className="md:hidden relative z-50 p-2 text-gray-900 bg-white/40 backdrop-blur-md rounded-full border border-white/20 shadow-sm"
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, backdropFilter: "blur(0px)" }}
            animate={{ opacity: 1, backdropFilter: "blur(12px)" }}
            exit={{ opacity: 0, backdropFilter: "blur(0px)" }}
            className="fixed inset-0 z-40 bg-white/90 flex flex-col items-center justify-center space-y-8 md:hidden"
          >
            <motion.div 
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.1 }}
               className="flex flex-col items-center gap-8"
            >
              <a href="#" onClick={toggleMenu} className="text-3xl font-bold text-gray-900 hover:text-red-600 transition-colors">Главная</a>
              <a href="#generator" onClick={toggleMenu} className="text-3xl font-bold text-gray-900 hover:text-red-600 transition-colors">AI Идеи</a>
              <a href="#tariffs" onClick={toggleMenu} className="text-3xl font-bold text-gray-900 hover:text-red-600 transition-colors">Тарифы</a>
              <a href="#contact" onClick={toggleMenu} className="text-3xl font-bold text-gray-900 hover:text-red-600 transition-colors">Контакты</a>
              
              <div className="w-12 h-1 bg-red-500 rounded-full opacity-20" />

              <a 
                href="https://t.me/bai_khairullin" 
                target="_blank" 
                rel="noreferrer" 
                className="px-8 py-4 bg-gray-900 text-white text-lg font-medium rounded-2xl shadow-xl active:scale-95 transition-transform"
              >
                Связаться в Telegram
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Hero />
      <IdeaGenerator />
      <Comparison />
      <Process />
      <Pricing />
      <Footer />
    </main>
  );
};

export default App;