import React, { useState, useEffect } from 'react';
import { Search, Repeat, ShieldCheck, Play } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';
import { motion, useScroll, useTransform } from 'framer-motion';

export const WhyYouTube: React.FC = () => {
    const [isDesktop, setIsDesktop] = useState(false);
    const { scrollYProgress } = useScroll();
    
    const yBg1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
    const yBg2 = useTransform(scrollYProgress, [0, 1], [0, 100]);

    useEffect(() => {
        const check = () => setIsDesktop(window.innerWidth >= 768);
        check();
        window.addEventListener('resize', check);
        return () => window.removeEventListener('resize', check);
    }, []);

  return (
    <section className="py-8 px-4 relative z-10 overflow-hidden">
        {/* Ambient Background for this section */}
        <div className="absolute inset-0 pointer-events-none -z-10">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-b from-transparent via-white/50 to-transparent" />
            
            <motion.div 
                style={{ y: isDesktop ? yBg1 : 0 }}
                className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-50/40 rounded-full blur-[120px] mix-blend-multiply" 
            />
            <motion.div 
                style={{ y: isDesktop ? yBg2 : 0 }}
                className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gray-100/50 rounded-full blur-[120px] mix-blend-multiply" 
            />
        </div>

        {/* Floating Particles - Silver/Blueish (Animated on Desktop) */}
        {[...Array(5)].map((_, i) => (
            <motion.div 
                key={i}
                animate={isDesktop ? {
                    y: [0, -40, 0],
                    x: [0, 20, 0],
                    opacity: [0.3, 0.6, 0.3],
                } : {}}
                transition={{
                    duration: 5 + i,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: i
                }}
                className="absolute rounded-full blur-sm bg-blue-100"
                style={{
                    width: Math.random() * 20 + 10 + 'px',
                    height: Math.random() * 20 + 10 + 'px',
                    top: Math.random() * 100 + '%',
                    left: Math.random() * 100 + '%',
                    opacity: 0.3
                }}
            />
        ))}

        <div className="max-w-5xl mx-auto">
            <motion.div
                initial={isDesktop ? { opacity: 0, y: 30 } : {}}
                whileInView={isDesktop ? { opacity: 1, y: 0 } : {}}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
            >
                <GlassCard 
                    className="md:p-16 p-8 !rounded-[3rem] relative overflow-hidden group border border-white/60 shadow-2xl shadow-blue-900/5"
                    intensity={10}
                >
                     {/* Internal Gloss/Gradient */}
                     <div className="absolute inset-0 bg-gradient-to-br from-white via-white/60 to-blue-50/30 opacity-90" />
                     
                     {/* Soft Highlights with Parallax */}
                     <motion.div 
                        style={{ y: isDesktop ? yBg1 : 0 }}
                        className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-100/50 to-purple-100/20 blur-3xl rounded-full pointer-events-none" 
                     />

                     <div className="relative z-10 flex flex-col items-center text-center">
                        
                        {/* Header with Icon */}
                        <div className="mb-8 relative">
                             <div className="absolute inset-0 bg-blue-400/20 blur-xl rounded-full transform scale-150 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                             <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-gray-50 to-white shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-white flex items-center justify-center relative z-10">
                                <Play className="w-8 h-8 text-gray-800 fill-gray-800" />
                             </div>
                        </div>

                        <h2 className="text-3xl md:text-5xl font-semibold tracking-tight text-gray-900 mb-10 max-w-4xl leading-[1.1]">
                            Почему YouTube работает <br className="hidden md:block" />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">для бизнеса</span>
                        </h2>

                        <div className="grid md:grid-cols-3 gap-6 md:gap-8 text-left mt-4 w-full">
                            {/* Point 1 */}
                            <div className="relative p-6 rounded-3xl bg-white/40 hover:bg-white/60 transition-colors duration-300 border border-white/40">
                                <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center mb-4 text-blue-600">
                                    <Search className="w-6 h-6" />
                                </div>
                                <p className="text-gray-700 leading-relaxed font-light text-base">
                                    <span className="font-semibold text-gray-900 block mb-2 text-lg">Сам приводит клиентов</span>
                                    Алгоритм подбирает ролики под запросы и показывает ваш контент тем, кто уже интересуется темой. Вас находят по поиску и рекомендациям.
                                </p>
                            </div>

                            {/* Point 2 */}
                            <div className="relative p-6 rounded-3xl bg-white/40 hover:bg-white/60 transition-colors duration-300 border border-white/40">
                                <div className="w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center mb-4 text-purple-600">
                                    <Repeat className="w-6 h-6" />
                                </div>
                                <p className="text-gray-700 leading-relaxed font-light text-base">
                                    <span className="font-semibold text-gray-900 block mb-2 text-lg">Работает годами</span>
                                    В отличие от Reels, где эффект длится неделю, YouTube работает годами. Один ролик продолжает приносить просмотры и заявки спустя 2–3 года.
                                </p>
                            </div>

                            {/* Point 3 */}
                            <div className="relative p-6 rounded-3xl bg-white/40 hover:bg-white/60 transition-colors duration-300 border border-white/40">
                                <div className="w-12 h-12 rounded-2xl bg-green-50 flex items-center justify-center mb-4 text-green-600">
                                    <ShieldCheck className="w-6 h-6" />
                                </div>
                                <p className="text-gray-700 leading-relaxed font-light text-base">
                                    <span className="font-semibold text-gray-900 block mb-2 text-lg">Накапливает доверие</span>
                                    Ваш канал становится системой, которая накапливает доверие и приводит людей, готовых покупать.
                                </p>
                            </div>
                        </div>

                     </div>
                </GlassCard>
            </motion.div>
        </div>
    </section>
  );
};