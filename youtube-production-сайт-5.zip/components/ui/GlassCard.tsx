import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  intensity?: number;
  highlight?: boolean;
}

export const GlassCard: React.FC<GlassCardProps> = ({ 
  children, 
  className = "", 
  highlight = false 
}) => {
  return (
    <div
      className={`relative rounded-3xl transition-all duration-200 group ${className}`}
    >
      {/* Glass Background */}
      <div 
        className={`absolute inset-0 rounded-3xl bg-gradient-to-br from-white/60 to-white/10 backdrop-blur-xl border border-white/40 shadow-[0_8px_32px_0_rgba(31,38,135,0.15)] 
        transition-all duration-300
        ${highlight ? 'shadow-red-500/20 border-red-500/20' : ''}
        group-hover:border-red-500/40 group-hover:shadow-[0_0_30px_rgba(239,68,68,0.25)]
        `}
      />
      
      {/* Glossy sheen */}
      <div 
        className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/40 via-transparent to-transparent opacity-50 pointer-events-none" 
      />

      {/* Content */}
      <div className="relative z-10 h-full">
        {children}
      </div>
    </div>
  );
};