import React from 'react';
import { Send, Phone, Mail, MessageCircle, ThumbsUp, FileText, CreditCard, ShieldCheck, Briefcase } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';

export const Footer: React.FC = () => {
  return (
    <footer id="contact" className="relative pt-8 pb-8 px-4 overflow-hidden">
      
      {/* --- Floating Footer Elements (Static) --- */}
      <div className="absolute top-10 left-[5%] md:left-[15%] hidden md:block opacity-60">
        <GlassCard className="w-16 h-16 flex items-center justify-center !rounded-2xl bg-blue-50/50 backdrop-blur-sm">
          <MessageCircle className="w-8 h-8 text-blue-400" />
        </GlassCard>
      </div>

      <div className="absolute bottom-20 right-[5%] md:right-[15%] hidden md:block opacity-60">
        <GlassCard className="w-20 h-20 flex items-center justify-center !rounded-2xl bg-red-50/50 backdrop-blur-sm">
          <ThumbsUp className="w-8 h-8 text-red-400" />
        </GlassCard>
      </div>

      <div className="absolute top-32 right-[10%] hidden lg:block opacity-50">
         <GlassCard className="w-12 h-12 flex items-center justify-center !rounded-xl bg-gray-50/50 backdrop-blur-sm">
            <Mail className="w-6 h-6 text-gray-400" />
         </GlassCard>
      </div>

      <div className="max-w-4xl mx-auto mb-16 relative z-10">
        <GlassCard className="p-10 md:p-16 text-center overflow-hidden relative">
            {/* Background Gradient inside card */}
            <div className="absolute inset-0 bg-gradient-to-br from-red-50/50 via-transparent to-transparent opacity-50" />
            
            <h2 className="text-4xl md:text-5xl font-bold mb-6 relative z-10 text-gray-900">Готовы начать?</h2>
            <p className="text-xl text-gray-600 mb-10 max-w-lg mx-auto relative z-10 font-light">
              Давайте обсудим ваш проект. Пишите в мессенджеры или звоните прямо сейчас.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10 mb-8 flex-wrap">
              <a 
                href="https://t.me/bai_khairullin" 
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-3 px-8 py-4 bg-[#229ED9] text-white rounded-2xl font-semibold shadow-lg shadow-blue-400/30 hover:shadow-blue-400/50 transition-all hover:-translate-y-1"
              >
                <Send className="w-5 h-5" />
                Telegram
              </a>

              <a 
                href="https://wa.me/79509465094" 
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-3 px-8 py-4 bg-[#25D366] text-white rounded-2xl font-semibold shadow-lg shadow-green-400/30 hover:shadow-green-400/50 transition-all hover:-translate-y-1"
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp
              </a>
              
              <a 
                href="https://t.me/+atBVAcGcoqYwYjYy" 
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-3 px-8 py-4 bg-gray-900 text-white rounded-2xl font-semibold shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
              >
                <Briefcase className="w-5 h-5" />
                Смотреть кейсы
              </a>

              <a 
                href="tel:+79509465094" 
                className="flex items-center justify-center gap-3 px-8 py-4 bg-white text-gray-900 border border-gray-200 rounded-2xl font-semibold shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
              >
                <Phone className="w-5 h-5" />
                +7(950)946-50-94
              </a>
            </div>

            {/* B2B Trust Indicators added below contacts */}
            <div className="flex flex-wrap justify-center gap-4 relative z-10 opacity-70">
              <div className="flex items-center gap-2 px-3 py-1 bg-white/40 rounded-full border border-gray-200/50">
                <FileText className="w-3 h-3 text-gray-500" />
                <span className="text-xs font-medium text-gray-600">Работа по договору (ИП)</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 bg-white/40 rounded-full border border-gray-200/50">
                <CreditCard className="w-3 h-3 text-gray-500" />
                <span className="text-xs font-medium text-gray-600">Безналичный расчет</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 bg-white/40 rounded-full border border-gray-200/50">
                <ShieldCheck className="w-3 h-3 text-gray-500" />
                <span className="text-xs font-medium text-gray-600">Win-Win партнерство</span>
              </div>
            </div>

        </GlassCard>
      </div>

      <div className="text-center text-gray-400 text-sm relative z-10">
        <p>© {new Date().getFullYear()} Bai Khairullin. All rights reserved.</p>
        <p className="mt-2">YouTube Producer</p>
      </div>
    </footer>
  );
};