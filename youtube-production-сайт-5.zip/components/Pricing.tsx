import React from 'react';
import { Check, Star, Video, Users, Zap, ArrowRight, ShieldCheck, Timer } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';

const tariffs = [
  {
    name: "Полный Бай продакшн",
    price: "280 000 ₽",
    period: "/ месяц",
    whoFor: "Для предпринимателей, которые хотят стабильный YouTube с сильной картинкой и регулярными выпусками.",
    icon: Star,
    description: "Мы берём на себя весь процесс: съёмка, монтаж, публикации, аналитика. Контент выходит уверенно и вовремя, бренд выглядит профессионально, а канал развивается без скачков.",
    features: [
      "4 выпуска 12–20 минут",
      "+28 shorts",
      "Профессиональная съемка",
      "Постановка кадра, свет, звук",
      "Монтаж, субтитры, графика",
      "Обложки, SEO, структура выпуска",
      "Публикации и описание",
      "Аналитика и корректировки"
    ],
    benefit: "У вас появляется стабильный контент, который усиливает бренд и привлекает обращения.",
    cta: "Хочу результат под ключ",
    featured: true,
    color: "red"
  },
  {
    name: "Удалённый Продакшн",
    price: "190 000 ₽",
    period: "/ месяц",
    whoFor: "Для тех, у кого есть возможность снимать самостоятельно, но нет времени и структуры для качественного выпуска.",
    icon: Video,
    description: "Вы снимаете сами, мы ведём канал полностью. Мы подключаемся онлайн на съемках и контролируем процесс: ракурсы, свет, подачу. Дальше всё делаем сами.",
    features: [
      "Онлайн сопровождение съемок",
      "Контроль качества кадра и подачи",
      "Монтаж до 4 выпусков до 20 минут",
      "Вырезка и создание +28 Shorts",
      "Субтитры, графика, звук",
      "Обложки, SEO, публикации",
      "Аналитика и корректировки"
    ],
    benefit: "Вы снимаете у себя, но получаете результат уровня продакшна.",
    cta: "Хочу удаленный продакшн",
    featured: false,
    color: "blue"
  },
  {
    name: "Online YouTube Продюсер",
    price: "79 000 ₽",
    period: "/ месяц",
    whoFor: "Подходит тем, у кого уже есть команда.",
    icon: Users,
    description: "Мы настраиваем систему работы, темы, подачу, сценарии. Контент становится ровнее, понятнее и сильнее влияет на аудиторию.",
    features: [
      "Стратегия канала",
      "Форматы под нишу",
      "Сценарии и структура выпусков",
      "Контроль оператора и монтажера",
      "Еженедельные созвоны"
    ],
    benefit: "Ваша команда начинает работать эффективнее, качество контента растет без увеличения расходов.",
    cta: "Хочу усилить команду",
    featured: false,
    color: "gray"
  }
];

export const Pricing: React.FC = () => {
  return (
    <section className="py-8 px-4 relative z-10" id="tariffs">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-4xl md:text-6xl font-black text-gray-900 mb-6 tracking-tight">
            Тарифы
          </h2>
          <p className="text-xl text-gray-600 font-light max-w-3xl mx-auto mb-10">
            Мы строим контент-систему, которая работает на результат, привлекает внимание и повышает доверие к вашему бренду.
          </p>

          {/* Discount Banner */}
          <div className="inline-flex flex-col md:flex-row items-center gap-2 md:gap-4 bg-gradient-to-r from-red-600 to-red-500 text-white px-8 py-4 rounded-2xl shadow-xl shadow-red-500/30 transform hover:scale-[1.02] transition-transform duration-300 mx-4">
             <div className="p-2 bg-white/20 rounded-full">
                <Timer className="w-6 h-6 animate-pulse" />
             </div>
             <div className="text-left">
                <span className="font-bold text-xl block leading-tight">Скидка 20% на первый месяц</span>
                <span className="text-red-100 text-sm font-medium opacity-90">на все пакеты при заключении договора в течение 7 дней</span>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {tariffs.map((tariff, idx) => (
            <div
              key={idx}
              className={`relative ${tariff.featured ? 'lg:-mt-4 z-10' : ''}`}
            >
              <GlassCard 
                highlight={tariff.featured} 
                intensity={10}
                className="p-8 h-full flex flex-col"
              >
                {tariff.featured && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-red-600 to-red-500 text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-lg z-20 tracking-wider flex items-center gap-1">
                    <Zap className="w-3 h-3 fill-current" />
                    РЕКОМЕНДУЮ
                  </div>
                )}
                
                {/* Header */}
                <div className="mb-6">
                    <div className={`w-12 h-12 rounded-2xl mb-6 flex items-center justify-center ${
                      tariff.featured ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600'
                    }`}>
                      <tariff.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{tariff.name}</h3>
                    <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-bold text-gray-900 tracking-tight">{tariff.price}</span>
                        <span className="text-gray-400 font-medium text-sm">{tariff.period}</span>
                    </div>
                </div>

                {/* Who is it for */}
                <div className="mb-4 p-3 rounded-xl bg-gray-50 border border-gray-100">
                    <p className="text-sm text-gray-600 italic leading-relaxed">"{tariff.whoFor}"</p>
                </div>
                
                {/* Description Text */}
                <div className="mb-6">
                    <p className="text-gray-600 text-sm leading-relaxed">
                        {tariff.description}
                    </p>
                </div>

                {/* Divider */}
                <div className="h-px bg-gray-100 w-full mb-6" />
                
                <div className="mb-6">
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-3 block">Что входит:</span>
                    <ul className="space-y-3">
                    {tariff.features.map((feat, i) => (
                        <li key={i} className="flex items-start gap-3 text-sm font-medium text-gray-700">
                        <div className={`p-0.5 rounded-full mt-0.5 shrink-0 ${tariff.featured ? 'bg-red-100 text-red-600' : 'bg-gray-200 text-gray-500'}`}>
                            <Check className="w-3 h-3" />
                        </div>
                        <span className="leading-snug">{feat}</span>
                        </li>
                    ))}
                    </ul>
                </div>

                {/* Main Benefit */}
                <div className={`mb-8 p-4 rounded-xl border ${tariff.featured ? 'bg-red-50 border-red-100' : 'bg-blue-50 border-blue-100'}`}>
                    <span className={`text-xs font-bold uppercase tracking-wide mb-1 block ${tariff.featured ? 'text-red-600' : 'text-blue-600'}`}>Главный смысл:</span>
                    <p className="text-sm font-bold text-gray-900 leading-snug">
                         {tariff.benefit}
                    </p>
                </div>

                <div className="mt-auto">
                    <a 
                    href="https://t.me/bai_khairullin" 
                    target="_blank"
                    rel="noreferrer"
                    className={`w-full py-4 px-4 rounded-xl font-bold text-sm md:text-base text-center transition-all shadow-lg active:scale-95 tracking-wide flex items-center justify-center gap-2 ${
                    tariff.featured 
                        ? 'bg-gradient-to-r from-red-600 to-red-500 text-white shadow-red-500/30 hover:shadow-red-500/50' 
                        : 'bg-white text-gray-900 shadow-gray-200/50 hover:bg-gray-50 border border-gray-100'
                    }`}>
                    <span className="flex-1">{tariff.cta}</span>
                    <ArrowRight className="w-4 h-4 shrink-0" />
                    </a>
                </div>
              </GlassCard>
            </div>
          ))}
        </div>

        {/* Bottom Note */}
        <div className="mt-16 text-center">
             <div className="inline-flex items-start md:items-center gap-3 bg-white/50 border border-gray-200 px-6 py-4 rounded-2xl text-left md:text-center mx-auto max-w-3xl backdrop-blur-sm shadow-sm">
                <ShieldCheck className="w-6 h-6 text-green-600 shrink-0 mt-0.5 md:mt-0" />
                <div className="text-sm text-gray-800 leading-relaxed">
                    <span className="font-bold text-gray-900 block md:inline mb-1 md:mb-0">Почему система работает: </span>
                    YouTube — это стратегия, регулярность и качество. Мы делаем контент, который <span className="text-green-600 font-semibold">привлекает внимание</span>, <span className="text-green-600 font-semibold">повышает доверие</span> и поддерживает <span className="text-green-600 font-semibold">стабильный рост</span>.
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};