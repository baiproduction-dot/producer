import React, { useState, useEffect, useCallback, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, X, Maximize2, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';

interface Photo {
  id: number;
  url: string;
  title: string;
}

const photos: Photo[] = [
  {
    id: 1,
    url: "https://sun9-55.userapi.com/s/v1/ig2/sOAa3EHYqRsitxt0v5IPfh1dG-THjDRC562wWTVbCrbIl1JfH1o0HYyeC8HR7QhWf3pWkuL_5dpy8XQJVK9Sh_ir.jpg?quality=95&as=32x51,48x76,72x114,108x171,160x253,240x379,360x569,480x758,540x853,640x1011,720x1138,1080x1707,1179x1863&from=bu&cs=1179x0",
    title: "Backstage 1",
  },
  {
    id: 2,
    url: "https://sun9-78.userapi.com/s/v1/ig2/4S2nrlyGBh75l9B8dnNN4_x6siHcg7ShA3MZ5u7P7ZkzWQeOgNgDETH9rfDKcOj_is1NApXMTle5WtfM8GkbY8CB.jpg?quality=95&as=32x48,48x72,72x108,108x162,160x240,240x360,360x540,480x720,540x810,640x960,720x1080,1080x1621,1280x1921,1440x2161,1706x2560&from=bu&cs=1706x0",
    title: "Backstage 2",
  },
  {
    id: 3,
    url: "https://sun9-17.userapi.com/s/v1/ig2/pS-2MRRYZfy_aMrrLiQisgBTKXciWjabDiPZP-z5uKyJRqWdjWH9BM-z8dFKtyZsoATuASwcUDiGe7aZlUQpAYdB.jpg?quality=95&as=32x57,48x85,72x128,108x192,160x284,240x427,360x640,480x853,540x960,640x1138,720x1280,1080x1920,1280x2276,1440x2560&from=bu&cs=1440x0",
    title: "Backstage 3",
  },
  {
    id: 4,
    url: "https://sun9-46.userapi.com/s/v1/ig2/9UWRX2T7Jb6TSmQS5yVghzOkI3iQ6FI9Ezdscpdcug6wkNGxHRJitKBuIe2PjWHkEmmfnEtAVMogiDrV0z--7ym_.jpg?quality=95&as=32x43,48x64,72x96,108x144,160x213,240x320,360x480,480x640,540x720,640x853,720x960,1080x1440,1280x1707,1440x1920,1920x2560&from=bu&cs=1920x0",
    title: "Backstage 4",
  },
  {
    id: 5,
    url: "https://sun9-51.userapi.com/s/v1/ig2/NvLLP3ktDAF2NVUlGWJDbNRjt_Dg0y4LxdcBsYiNTeXsdYVEyzZNW2UofmtsojaJ1GTIGBGaD3SBn73DgJGCgcl5.jpg?quality=95&as=32x57,48x85,72x128,108x192,160x284,240x427,360x640,480x853,540x960,640x1138,720x1280,1080x1920,1280x2276,1440x2560&from=bu&cs=1440x0",
    title: "Backstage 5",
  },
  {
    id: 6,
    url: "https://sun9-25.userapi.com/s/v1/ig2/fluAOz6K8BDogf7VAGM5hcojcPLcDD75JOfdSi2QhcENohZW5_mcJU-A5fLWpiMeofW5mybxbYyiWI07_M4QRg4p.jpg?quality=95&as=32x57,48x85,72x128,108x192,160x284,240x427,360x640,480x853,540x960,640x1138,720x1280,1080x1920,1280x2276,1440x2560&from=bu&cs=1440x0",
    title: "Backstage 6",
  },
  {
    id: 7,
    url: "https://sun9-17.userapi.com/s/v1/ig2/CgAk8pSPBZygvQX_didI36hCHox4aOt3yXcVOQCDZXW1lQb8eEARIKgVKLzFf1npiTvPrOGeH1Sl4o9D2Ra6O3Tb.jpg?quality=95&as=32x43,48x64,72x96,108x144,160x213,240x320,360x480,480x640,540x720,640x853,720x960,1080x1440,1280x1707,1440x1920,1920x2560&from=bu&cs=1920x0",
    title: "Backstage 7",
  },
  {
    id: 8,
    url: "https://sun9-36.userapi.com/s/v1/ig2/CmH7CaY-8Tf2Y0mCE5f3_zu97Sf9TDfmRFAcV2i23OKc75UoKG6QXogu6jYES3lRDIDE2uqDKrzkJqt_LM7Tm86g.jpg?quality=95&as=32x43,48x64,72x96,108x144,160x213,240x320,360x480,480x640,540x720,640x853,720x960,1080x1440,1280x1707,1440x1920,1920x2560&from=bu&cs=1920x0",
    title: "Backstage 8",
  },
  {
    id: 9,
    url: "https://sun9-74.userapi.com/s/v1/ig2/O2X_IqqKAfzo8Ahr4HOB7cc89UBQkKNzX08pRGOelyObKHNVz8JH11kuIDd3tILiO3kXmzhmOAGKsjtG0j0QFGpx.jpg?quality=95&as=32x43,48x64,72x96,108x144,160x213,240x320,360x480,480x640,540x720,640x853,720x960,1080x1440,1280x1707,1440x1920,1920x2560&from=bu&cs=1920x0",
    title: "Backstage 9",
  },
  {
    id: 10,
    url: "https://sun9-86.userapi.com/s/v1/ig2/9mFx_IHptQ3mIyIw4FEbiOMG1SWS8IkhOqeY4WiKn5hqw3728niBWMfbKZzYndJx_p2SBahs11eFRwZrnWJSL0zZ.jpg?quality=95&as=32x57,48x85,72x128,108x192,160x284,240x427,360x640,480x853,540x960,640x1138,720x1280,1080x1920,1280x2276,1440x2560&from=bu&cs=1440x0",
    title: "Backstage 10",
  },
  {
    id: 11,
    url: "https://sun9-47.userapi.com/s/v1/ig2/ZPW_Nm7MwnaMv-AStlMghpfAzkV1jxs0_77hKleKLYi7Zvgjas00gH3Wo5UhYAlSgsyRPdK6aTv9CgsBJjHII_Te.jpg?quality=95&as=32x57,48x85,72x128,108x192,160x284,240x427,360x640,480x853,540x960,640x1138,720x1280,1080x1920,1280x2276,1440x2560&from=bu&cs=1440x0",
    title: "Backstage 11",
  },
  {
    id: 12,
    url: "https://sun9-30.userapi.com/s/v1/ig2/kdDoqZN-cUt8e5OCUXIFMyp0t_qupKKbLxqwRBD5VyuHrKKc80-kap41A0wo3Q9tmQ4-UtI3k5VZkw7isRr7WnRB.jpg?quality=95&as=32x57,48x85,72x128,108x192,160x284,240x427,360x640,480x853,540x960,640x1138,720x1280,1080x1920,1280x2276,1440x2560&from=bu&cs=1440x0",
    title: "Backstage 12",
  }
];

// Optimized Image Component with Skeleton Loading
const GalleryImage = memo(({ photo, index, isDesktop, onClick }: { photo: Photo; index: number; isDesktop: boolean; onClick: () => void }) => {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <motion.div
      className="relative group rounded-xl overflow-hidden cursor-zoom-in shadow-sm hover:shadow-lg transition-all duration-500 aspect-[9/16] bg-gray-100"
      initial={isDesktop ? { opacity: 0, scale: 0.95 } : { opacity: 0, y: 20 }}
      whileInView={isDesktop ? { opacity: 1, scale: 1 } : { opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "50px" }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      onClick={onClick}
    >
      {/* Skeleton Loader */}
      {isLoading && (
        <div className="absolute inset-0 bg-gray-200 animate-pulse flex items-center justify-center z-0">
             <Camera className="w-8 h-8 text-gray-300 opacity-50" />
        </div>
      )}

      {/* Image */}
      <img
        src={photo.url}
        alt={photo.title}
        className={`w-full h-full object-cover transition-all duration-700 group-hover:scale-105 ${
          isLoading ? 'opacity-0 scale-105' : 'opacity-100 scale-100'
        }`}
        loading="lazy"
        decoding="async"
        onLoad={() => setIsLoading(false)}
        // Provide sizes hint to browser
        sizes="(max-width: 768px) 50vw, 25vw"
      />

      {/* Hover Overlay */}
      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-10">
        <div className="bg-white/90 rounded-full p-2 backdrop-blur-sm shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
          <Maximize2 className="w-5 h-5 text-gray-900" />
        </div>
      </div>
    </motion.div>
  );
});

export const BackstageGallery: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [isDesktop, setIsDesktop] = useState(false);

  useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  // Keyboard navigation
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (selectedIndex === null) return;

    if (e.key === 'ArrowRight') {
      setSelectedIndex((prev) => (prev === null ? null : (prev + 1) % photos.length));
    } else if (e.key === 'ArrowLeft') {
      setSelectedIndex((prev) => (prev === null ? null : (prev - 1 + photos.length) % photos.length));
    } else if (e.key === 'Escape') {
      setSelectedIndex(null);
    }
  }, [selectedIndex]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedIndex((prev) => (prev === null ? null : (prev + 1) % photos.length));
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedIndex((prev) => (prev === null ? null : (prev - 1 + photos.length) % photos.length));
  };

  return (
    <section className="py-10 px-4 relative z-10 overflow-hidden bg-gray-50/50">
      
      {/* --- Ambient Background --- */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-[10%] w-[50vw] h-[50vw] bg-gray-200/40 rounded-full blur-[120px] mix-blend-multiply" />
        <div className="absolute bottom-0 right-[10%] w-[40vw] h-[40vw] bg-blue-100/40 rounded-full blur-[100px] mix-blend-multiply" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Header */}
        <div className="text-center mb-8 max-w-3xl mx-auto">
          <motion.div
            initial={isDesktop ? { opacity: 0, y: 20 } : {}}
            whileInView={isDesktop ? { opacity: 1, y: 0 } : {}}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/60 backdrop-blur-md border border-white/50 text-gray-500 text-sm font-semibold uppercase tracking-wider mb-4 shadow-sm">
              <Camera className="w-4 h-4" />
              <span>Production Life</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4 tracking-tight">
              Backstage
            </h2>
          </motion.div>
        </div>

        {/* Grid - 2 columns mobile, 4 columns desktop */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 auto-rows-auto">
          {photos.map((photo, idx) => (
            <GalleryImage 
              key={photo.id}
              photo={photo}
              index={idx}
              isDesktop={isDesktop}
              onClick={() => setSelectedIndex(idx)}
            />
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedIndex(null)}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-sm flex items-center justify-center p-4"
          >
             {/* Main container for image and specific controls */}
             <div 
                className="relative max-w-full max-h-full flex items-center justify-center"
                onClick={(e) => e.stopPropagation()}
             >
                {/* Image */}
                <motion.img 
                  key={selectedIndex}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3 }}
                  src={photos[selectedIndex].url} 
                  alt={photos[selectedIndex].title}
                  className="max-h-[85vh] max-w-[90vw] object-contain rounded-lg shadow-2xl select-none"
                  draggable={false}
                />

                {/* Close Button */}
                <button 
                  onClick={() => setSelectedIndex(null)}
                  className="absolute -top-12 right-0 md:top-4 md:right-4 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-20"
                >
                  <X className="w-6 h-6" />
                </button>

                {/* Nav Buttons */}
                <button 
                  onClick={handlePrev}
                  className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 p-3 bg-black/50 hover:bg-black/80 text-white rounded-full transition-colors z-20"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>

                <button 
                  onClick={handleNext}
                  className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 p-3 bg-black/50 hover:bg-black/80 text-white rounded-full transition-colors z-20"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>

                {/* Counter */}
                <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 text-white/60 text-sm font-medium">
                   {selectedIndex + 1} / {photos.length}
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
};
