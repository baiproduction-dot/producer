import React, { useState, useEffect } from 'react';
import { X, Check, Activity, Frown, Smile, ArrowUpRight } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';
import { motion } from 'framer-motion';

export const Comparison: React.FC = () => {
  const [isDesktop, setIsDesktop] = useState(false);

  useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return (
    <section className="py-8 px-4 relative z-10">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-8 text-gray-900">
          Результат
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {/* Without Me */}
          <div>
            <GlassCard className="p-8 md:p-12 min-h-[500px] flex flex-col justify-between group">
              <div className="space-y-6">
                <div className="w-16 h-16 rounded-2xl bg-gray-200/50 flex items-center justify-center mb-6">
                  <Frown className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-3xl font-bold text-gray-400">Без продюсера</h3>
                <ul className="space-y-4">
                  {["Хаотичный выход роликов", "Слабое удержание аудитории", "Нет стратегии продвижения", "Низкое качество картинки"].map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-gray-500">
                      <X className="w-5 h-5 mt-0.5 text-gray-400 shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-8 pt-8 border-t border-gray-200/20">
                <div className="h-24 w-full bg-gray-200/30 rounded-xl relative overflow-hidden flex items-end pb-2 px-2 gap-1">
                  {[40, 35, 45, 30, 25, 30, 20].map((h, i) => (
                      <div key={i} style={{ height: `${h}%` }} className="flex-1 bg-gray-300 rounded-sm opacity-50" />
                  ))}
                </div>
                <p className="text-sm text-gray-400 mt-2 text-center">Стагнация канала</p>
              </div>
            </GlassCard>
          </div>

          {/* With Me */}
          <div>
            <GlassCard highlight={true} className="p-8 md:p-12 min-h-[500px] flex flex-col justify-between">
              <div className="space-y-6">
                <div className="w-16 h-16 rounded-2xl bg-red-100 flex items-center justify-center mb-6 shadow-lg shadow-red-500/20">
                  <Smile className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-3xl font-bold text-gray-900">Со мной</h3>
                <ul className="space-y-4">
                  {["Регулярный контент", "Ваш YouTube на автопилоте", "Вы лежите на пляже, а канал набирает просмотры", "Ваш канал сам находит клиентов"].map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-gray-800 font-medium">
                      <Check className="w-5 h-5 mt-0.5 text-red-500 shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-8 pt-8 border-t border-red-100">
                <div className="h-24 w-full bg-gradient-to-t from-red-50/50 to-transparent rounded-xl relative overflow-hidden flex items-end pb-2 px-2 gap-1">
                  {[20, 35, 45, 60, 55, 80, 95].map((h, i) => (
                      <motion.div 
                          key={i} 
                          initial={isDesktop ? { height: '10%' } : { height: `${h}%` }}
                          whileInView={isDesktop ? { height: `${h}%` } : {}}
                          viewport={{ once: true }}
                          transition={{ duration: 1, delay: i * 0.1 }}
                          className="flex-1 bg-gradient-to-t from-red-600 to-red-400 rounded-sm shadow-[0_0_10px_rgba(220,38,38,0.5)]" 
                      />
                  ))}
                </div>
                <div className="flex justify-between items-center mt-3">
                  <div className="flex flex-col">
                    <p className="text-sm text-red-600 font-semibold flex items-center gap-1">
                        Рост канала <Activity className="w-3 h-3" />
                    </p>
                    <a 
                      href="https://t.me/+atBVAcGcoqYwYjYy" 
                      target="_blank" 
                      rel="noreferrer"
                      className="text-xs text-gray-400 underline decoration-gray-300 hover:text-red-500 hover:decoration-red-400 transition-all flex items-center gap-1 mt-0.5"
                    >
                      Подтверждение (кейсы) <ArrowUpRight className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>
      </div>
    </section>
  );
};