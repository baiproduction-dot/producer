import React from 'react';
import { Briefcase, ArrowRight } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';

export const CasesCTA: React.FC = () => {
  return (
    <section className="py-8 px-4 relative z-20">
      <div className="max-w-4xl mx-auto">
        <GlassCard className="p-8 md:p-12 !rounded-[2.5rem] relative overflow-hidden group">
          {/* Animated Gradient Background */}
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-red-500/10 opacity-50 group-hover:opacity-100 transition-opacity duration-500" />
          
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
            <div className="flex-1">
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 bg-white/60 backdrop-blur-sm rounded-full border border-white/50 w-fit mx-auto md:mx-0">
                <Briefcase className="w-4 h-4 text-gray-600" />
                <span className="text-xs font-bold text-gray-600 uppercase tracking-wide">Портфолио</span>
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                Посмотрите реальные кейсы
              </h3>
              <p className="text-gray-600 text-lg">
                Примеры работ, статистика каналов и результаты клиентов в моем Telegram-канале.
              </p>
            </div>

            <a 
              href="https://t.me/+atBVAcGcoqYwYjYy"
              target="_blank"
              rel="noreferrer"
              className="px-12 py-6 bg-[#229ED9] text-white text-xl md:text-2xl font-bold rounded-2xl shadow-xl shadow-blue-400/30 flex items-center gap-3 hover:bg-[#1f92c9] transition-all shrink-0 transform hover:scale-105 active:scale-95"
            >
              Перейти к кейсам
              <ArrowRight className="w-6 h-6" />
            </a>
          </div>
        </GlassCard>
      </div>
    </section>
  );
};