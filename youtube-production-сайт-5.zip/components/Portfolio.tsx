import React, { useState, useEffect } from 'react';
import { TrendingUp, MessageCircle, BarChart3, Layers, Zap, PenTool, ArrowRight, Play, CheckCircle2 } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';
import { motion, useScroll, useTransform } from 'framer-motion';

export const Portfolio: React.FC = () => {
  const [isDesktop, setIsDesktop] = useState(false);
  const { scrollYProgress } = useScroll();
  
  // Parallax Values
  const yBlob1 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const yBlob2 = useTransform(scrollYProgress, [0, 1], [0, -150]);

  useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return (
    <section className="py-12 px-4 relative z-10 overflow-hidden">
      {/* Ambient Background */}
      <div className="absolute inset-0 pointer-events-none -z-10">
        <motion.div 
            style={{ y: isDesktop ? yBlob1 : 0 }}
            className="absolute top-[20%] left-[10%] w-[500px] h-[500px] bg-blue-100/30 rounded-full blur-[100px]" 
        />
        <motion.div 
            style={{ y: isDesktop ? yBlob2 : 0 }}
            className="absolute bottom-[20%] right-[10%] w-[600px] h-[600px] bg-purple-100/20 rounded-full blur-[120px]" 
        />
        
        {/* Floating Particles (Animated on Desktop) */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            animate={isDesktop ? {
              y: [0, -30, 0],
              opacity: [0.3, 0.6, 0.3],
            } : {}}
            transition={{
              duration: 4 + i,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i
            }}
            className="absolute rounded-full bg-gradient-to-br from-white to-blue-200 blur-sm"
            style={{
              width: Math.random() * 10 + 5 + 'px',
              height: Math.random() * 10 + 5 + 'px',
              top: Math.random() * 80 + 10 + '%',
              left: Math.random() * 90 + 5 + '%',
              opacity: 0.4
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* 1. Hero Block */}
        <motion.div
            initial={isDesktop ? { opacity: 0, y: 30 } : {}}
            whileInView={isDesktop ? { opacity: 1, y: 0 } : {}}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
        >
          <GlassCard className="p-8 md:p-16 text-center relative overflow-visible">
            {/* Decor Elements (Animated on Desktop) */}
            <motion.div 
              animate={isDesktop ? { rotate: [0, 10, 0], y: [0, -10, 0] } : {}}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-6 -right-6 md:top-10 md:right-10 w-16 h-16 bg-white/80 backdrop-blur-md rounded-2xl shadow-xl flex items-center justify-center border border-white/50 z-20"
            >
              <TrendingUp className="w-8 h-8 text-green-500" />
            </motion.div>
            
            <motion.div 
              animate={isDesktop ? { rotate: [0, -10, 0], y: [0, -15, 0] } : {}}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute -bottom-6 -left-6 md:bottom-10 md:left-10 w-20 h-20 bg-white/80 backdrop-blur-md rounded-2xl shadow-xl flex items-center justify-center border border-white/50 z-20"
            >
              <Play className="w-8 h-8 text-red-500 fill-red-500" />
            </motion.div>

            <h2 className="text-3xl md:text-5xl lg:text-6xl font-black text-gray-900 mb-6 uppercase tracking-tight leading-tight">
              Мы запускаем YouTube-каналы: <br className="hidden lg:block"/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">От нуля до экспертной узнаваемости</span>
            </h2>
            <p className="text-xl text-gray-600 font-light max-w-3xl mx-auto mb-10 leading-relaxed">
              Создаем контент, который решает ключевую задачу бизнеса и делает бренд видимым.
            </p>
            
            <a 
              href="https://t.me/bai_khairullin"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-3 px-8 py-4 bg-gray-900 text-white text-lg font-bold rounded-full shadow-lg hover:bg-black transition-all hover:-translate-y-1 active:scale-95"
            >
              Связаться в Telegram
              <ArrowRight className="w-5 h-5" />
            </a>
          </GlassCard>
        </motion.div>

        {/* 2. Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: BarChart3,
              color: "text-blue-600",
              bg: "bg-blue-50",
              value: "+45K–50K",
              label: "Средние просмотры",
              sub: "Shorts"
            },
            {
              icon: MessageCircle,
              color: "text-purple-600",
              bg: "bg-purple-50",
              value: "+100",
              label: "Комментариев",
              sub: "Живое комьюнити"
            },
            {
              icon: TrendingUp,
              color: "text-green-600",
              bg: "bg-green-50",
              value: "+61 000",
              label: "Просмотров с ролика",
              sub: "Долгосрочный эффект"
            }
          ].map((item, idx) => (
            <motion.div 
                key={idx}
                initial={isDesktop ? { opacity: 0, scale: 0.9 } : {}}
                whileInView={isDesktop ? { opacity: 1, scale: 1 } : {}}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
            >
              <GlassCard className="p-8 h-full flex flex-col items-center text-center hover:bg-white/40 transition-colors">
                <div className={`w-14 h-14 rounded-2xl ${item.bg} ${item.color} flex items-center justify-center mb-6 shadow-sm`}>
                  <item.icon className="w-7 h-7" />
                </div>
                <div className="text-4xl font-black text-gray-900 mb-2 tracking-tight">{item.value}</div>
                <div className="text-lg font-bold text-gray-800 mb-1">{item.label}</div>
                <div className="text-sm text-gray-500 font-medium bg-white/50 px-3 py-1 rounded-full border border-gray-100">
                  {item.sub}
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>

        {/* 3. Services */}
        <div className="relative">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-black text-gray-900 uppercase tracking-wide">
              Мы делаем проекты под ключ
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Стратегия и Продюсирование",
                desc: "Полный запуск с нуля. Анализ конкурентов, разработка контент-плана и поиск вашего уникального голоса.",
                icon: Layers
              },
              {
                title: "Разнообразие Форматов",
                desc: "От экспертных интервью и обзоров до документальных фильмов и вирусных Shorts.",
                icon: Zap
              },
              {
                title: "Глубокое Погружение",
                desc: "Работаем со сложными нишами: строительство, автобизнес, медицина, финансы. Говорим на языке вашей аудитории.",
                icon: PenTool
              }
            ].map((service, idx) => (
              <motion.div
                key={idx}
                initial={isDesktop ? { opacity: 0, y: 20 } : {}}
                whileInView={isDesktop ? { opacity: 1, y: 0 } : {}}
                viewport={{ once: true }}
                transition={{ delay: 0.2 + (idx * 0.1) }}
                className="transform transition-transform hover:-translate-y-2"
              >
                <GlassCard className="p-8 h-full flex flex-col justify-between group border-t-4 border-t-transparent hover:border-t-blue-500 transition-all">
                  <div>
                    <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-500 group-hover:text-white transition-colors duration-300">
                      <service.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                    <p className="text-gray-600 leading-relaxed text-sm">
                      {service.desc}
                    </p>
                  </div>
                  <div className="mt-6 flex items-center text-blue-600 text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Входит в пакет
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};